"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { LayoutDashboard, Users, CreditCard, Bell, Receipt, BarChart3, Settings } from "lucide-react"

const menuItems = [
  {
    href: "/",
    label: "Ana Səhifə",
    icon: LayoutDashboard,
  },
  {
    href: "/students",
    label: "Tələbələr",
    icon: Users,
  },
  {
    href: "/payments",
    label: "Ödənişlər",
    icon: CreditCard,
  },
  {
    href: "/reminders",
    label: "Xatırlatmalar",
    icon: Bell,
  },
  {
    href: "/receipts",
    label: "Qəbzlər",
    icon: Receipt,
  },
  {
    href: "/analytics",
    label: "Hesabatlar",
    icon: BarChart3,
  },
  {
    href: "/settings",
    label: "Parametrlər",
    icon: Settings,
  },
]

export function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r border-border bg-card">
      <div className="flex h-16 items-center gap-2 border-b border-border px-6">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
          <CreditCard className="h-5 w-5 text-primary-foreground" />
        </div>
        <span className="text-lg font-semibold">Ödəniş Sistemi</span>
      </div>
      <nav className="space-y-1 p-4">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground",
              )}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </Link>
          )
        })}
      </nav>
    </aside>
  )
}
