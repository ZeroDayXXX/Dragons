import { cn } from "@/lib/utils"
import type { PaymentStatus } from "@/lib/mock-data"

interface StatusBadgeProps {
  status: PaymentStatus
}

export function StatusBadge({ status }: StatusBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        status === "ödənilib" && "bg-success/10 text-success",
        status === "gözləyir" && "bg-warning/10 text-warning-foreground",
        status === "gecikib" && "bg-destructive/10 text-destructive",
        status === "qismən" && "bg-primary/10 text-primary",
      )}
    >
      {status === "ödənilib" && "Ödənilib"}
      {status === "gözləyir" && "Gözləyir"}
      {status === "gecikib" && "Gecikib"}
      {status === "qismən" && "Qismən"}
    </span>
  )
}
