// Render Sidebar
function renderSidebar() {
  const currentPage = window.location.pathname.split("/").pop() || "index.html"

  const sidebar = `
    <div class="sidebar">
      <div class="sidebar-logo">
        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="12" x2="12" y1="2" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
        </svg>
        <h2>Ödəniş Sistemi</h2>
      </div>
      <nav class="sidebar-nav">
        <a href="index.html" class="sidebar-link ${currentPage === "index.html" ? "active" : ""}">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>
          </svg>
          <span>Ana Səhifə</span>
        </a>
        <a href="students.html" class="sidebar-link ${currentPage === "students.html" ? "active" : ""}">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
          </svg>
          <span>Tələbələr</span>
        </a>
        <a href="payments.html" class="sidebar-link ${currentPage === "payments.html" ? "active" : ""}">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/>
          </svg>
          <span>Ödənişlər</span>
        </a>
        <a href="receipts.html" class="sidebar-link ${currentPage === "receipts.html" ? "active" : ""}">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 17.5v-11"/>
          </svg>
          <span>Qəbzlər</span>
        </a>
        <a href="reminders.html" class="sidebar-link ${currentPage === "reminders.html" ? "active" : ""}">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
          </svg>
          <span>Xatırlatmalar</span>
        </a>
        <a href="analytics.html" class="sidebar-link ${currentPage === "analytics.html" ? "active" : ""}">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="M7 16 17 6"/><path d="m10 9 3 3 6-6"/>
          </svg>
          <span>Analitika</span>
        </a>
        <a href="settings.html" class="sidebar-link ${currentPage === "settings.html" ? "active" : ""}">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>
          </svg>
          <span>Parametrlər</span>
        </a>
      </nav>
    </div>
  `

  document.getElementById("sidebar").innerHTML = sidebar
}

// Render Header
function renderHeader() {
  const header = `
    <div class="header">
      <div class="header-search">
        <input type="text" placeholder="Axtar...">
      </div>
      <div class="header-actions">
        <div class="header-user">
          <div>
            <p style="font-weight: 600; font-size: 0.875rem;">Admin İstifadəçi</p>
            <p style="font-size: 0.75rem; color: var(--muted-foreground);">admin@example.com</p>
          </div>
          <div class="header-avatar">A</div>
        </div>
      </div>
    </div>
  `

  document.getElementById("header").innerHTML = header
}

// Get Status Badge
function getStatusBadge(status) {
  const badges = {
    ödənilib: '<span class="badge badge-success">Ödənilib</span>',
    gecikib: '<span class="badge badge-destructive">Gecikib</span>',
    qismən: '<span class="badge badge-warning">Qismən</span>',
    gözləyir: '<span class="badge badge-secondary">Gözləyir</span>',
    göndərilib: '<span class="badge badge-success">Göndərilib</span>',
    uğursuz: '<span class="badge badge-destructive">Uğursuz</span>',
    təsdiqlənib: '<span class="badge badge-success">Təsdiqlənib</span>',
    "rədd edilib": '<span class="badge badge-destructive">Rədd edilib</span>',
  }
  return badges[status] || ""
}

// Initialize common components
document.addEventListener("DOMContentLoaded", () => {
  renderSidebar()
  renderHeader()
})
