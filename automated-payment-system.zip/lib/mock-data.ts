export type PaymentStatus = "ödənilib" | "gözləyir" | "gecikib" | "qismən"

export type Student = {
  id: string
  ad: string
  soyad: string
  telefon: string
  email: string
  qeydiyyatTarixi: string
  plan: PaymentPlan
  status: PaymentStatus
  nextPaymentDate: string
  totalDebt: number
  paidAmount: number
  group_id: string
}

export type PaymentPlan = {
  id: string
  ad: string
  məbləğ: number
  müddət: "aylıq" | "illik" | "həftəlik"
  description: string
}

export type Payment = {
  id: string
  studentId: string
  studentAd: string
  məbləğ: number
  tarix: string
  status: PaymentStatus
  qəbz?: string
  qeyd?: string
}

export type Reminder = {
  id: string
  studentId: string
  studentAd: string
  telefon: string
  növ: "sms" | "whatsapp"
  mesaj: string
  göndərilməTarixi?: string
  status: "gözləyir" | "göndərilib" | "uğursuz"
  planlanmışTarix: string
}

export type Group = {
  id: string
  ad: string
}

export const paymentPlans: PaymentPlan[] = [
  {
    id: "1",
    ad: "Aylıq Standart",
    məbləğ: 150,
    müddət: "aylıq",
    description: "Standart aylıq paket - bütün dərslər daxildir",
  },
  {
    id: "2",
    ad: "Aylıq Premium",
    məbləğ: 250,
    müddət: "aylıq",
    description: "Premium paket - fərdi dərs və əlavə materiallar",
  },
  {
    id: "3",
    ad: "İllik Endiriml ı",
    məbləğ: 1500,
    müddət: "illik",
    description: "İllik ödəniş - 20% endirim",
  },
]

export const groups: Group[] = [
  { id: "1", ad: "Qrup A - Səhər" },
  { id: "2", ad: "Qrup B - Günorta" },
  { id: "3", ad: "Qrup C - Axşam" },
  { id: "4", ad: "Qrup D - Həftəsonu" },
]

export const students: Student[] = [
  {
    id: "1",
    ad: "Ayşən",
    soyad: "Məmmədova",
    telefon: "+994 50 123 45 67",
    email: "aysen@example.com",
    qeydiyyatTarixi: "2024-01-15",
    plan: paymentPlans[0],
    status: "ödənilib",
    nextPaymentDate: "2024-04-15",
    totalDebt: 0,
    paidAmount: 450,
    group_id: "1",
  },
  {
    id: "2",
    ad: "Elvin",
    soyad: "Həsənov",
    telefon: "+994 51 234 56 78",
    email: "elvin@example.com",
    qeydiyyatTarixi: "2024-02-01",
    plan: paymentPlans[1],
    status: "gecikib",
    nextPaymentDate: "2024-03-01",
    totalDebt: 500,
    paidAmount: 250,
    group_id: "2",
  },
  {
    id: "3",
    ad: "Leyla",
    soyad: "İbrahimova",
    telefon: "+994 55 345 67 89",
    email: "leyla@example.com",
    qeydiyyatTarixi: "2024-01-20",
    plan: paymentPlans[0],
    status: "qismən",
    nextPaymentDate: "2024-03-20",
    totalDebt: 75,
    paidAmount: 375,
    group_id: "1",
  },
  {
    id: "4",
    ad: "Rəşad",
    soyad: "Əliyev",
    telefon: "+994 70 456 78 90",
    email: "reshad@example.com",
    qeydiyyatTarixi: "2024-02-10",
    plan: paymentPlans[2],
    status: "ödənilib",
    nextPaymentDate: "2025-02-10",
    totalDebt: 0,
    paidAmount: 1500,
    group_id: "3",
  },
  {
    id: "5",
    ad: "Nigar",
    soyad: "Quliyeva",
    telefon: "+994 77 567 89 01",
    email: "nigar@example.com",
    qeydiyyatTarixi: "2024-02-15",
    plan: paymentPlans[0],
    status: "gözləyir",
    nextPaymentDate: "2024-03-25",
    totalDebt: 150,
    paidAmount: 150,
    group_id: "2",
  },
  {
    id: "6",
    ad: "Kamran",
    soyad: "Vəliyev",
    telefon: "+994 50 987 65 43",
    email: "kamran@example.com",
    qeydiyyatTarixi: "2024-03-01",
    plan: paymentPlans[0],
    status: "ödənilib",
    nextPaymentDate: "2024-04-01",
    totalDebt: 0,
    paidAmount: 150,
    group_id: "4",
  },
  {
    id: "7",
    ad: "Səbinə",
    soyad: "Məhərrəmova",
    telefon: "+994 55 876 54 32",
    email: "sebine@example.com",
    qeydiyyatTarixi: "2024-02-20",
    plan: paymentPlans[1],
    status: "gecikib",
    nextPaymentDate: "2024-03-20",
    totalDebt: 250,
    paidAmount: 250,
    group_id: "3",
  },
  {
    id: "8",
    ad: "Tural",
    soyad: "Abdullayev",
    telefon: "+994 70 765 43 21",
    email: "tural@example.com",
    qeydiyyatTarixi: "2024-01-25",
    plan: paymentPlans[0],
    status: "qismən",
    nextPaymentDate: "2024-03-25",
    totalDebt: 100,
    paidAmount: 350,
    group_id: "1",
  },
]

export const payments: Payment[] = [
  {
    id: "1",
    studentId: "1",
    studentAd: "Ayşən Məmmədova",
    məbləğ: 150,
    tarix: "2024-03-15",
    status: "ödənilib",
    qəbz: "/receipts/001.jpg",
    qeyd: "Bank köçürməsi",
  },
  {
    id: "2",
    studentId: "2",
    studentAd: "Elvin Həsənov",
    məbləğ: 250,
    tarix: "2024-02-01",
    status: "ödənilib",
    qəbz: "/receipts/002.jpg",
  },
  {
    id: "3",
    studentId: "3",
    studentAd: "Leyla İbrahimova",
    məbləğ: 75,
    tarix: "2024-03-10",
    status: "qismən",
    qeyd: "Qismən ödəniş - qalan 75 AZN",
  },
  {
    id: "4",
    studentId: "1",
    studentAd: "Ayşən Məmmədova",
    məbləğ: 150,
    tarix: "2024-02-15",
    status: "ödənilib",
    qəbz: "/receipts/004.jpg",
    qeyd: "Nağd ödəniş",
  },
  {
    id: "5",
    studentId: "4",
    studentAd: "Rəşad Əliyev",
    məbləğ: 1500,
    tarix: "2024-02-10",
    status: "ödənilib",
    qəbz: "/receipts/005.jpg",
    qeyd: "İllik paket - bank köçürməsi",
  },
  {
    id: "6",
    studentId: "6",
    studentAd: "Kamran Vəliyev",
    məbləğ: 150,
    tarix: "2024-03-01",
    status: "ödənilib",
    qeyd: "Nağd",
  },
  {
    id: "7",
    studentId: "7",
    studentAd: "Səbinə Məhərrəmova",
    məbləğ: 250,
    tarix: "2024-02-20",
    status: "ödənilib",
    qəbz: "/receipts/007.jpg",
  },
  {
    id: "8",
    studentId: "8",
    studentAd: "Tural Abdullayev",
    məbləğ: 50,
    tarix: "2024-03-12",
    status: "qismən",
    qeyd: "İlk qismən ödəniş",
  },
  {
    id: "9",
    studentId: "5",
    studentAd: "Nigar Quliyeva",
    məbləğ: 150,
    tarix: "2024-02-15",
    status: "ödənilib",
    qəbz: "/receipts/009.jpg",
  },
  {
    id: "10",
    studentId: "2",
    studentAd: "Elvin Həsənov",
    məbləğ: 250,
    tarix: "2024-01-05",
    status: "ödənilib",
    qeyd: "İlk ay ödənişi",
  },
]

export const reminders: Reminder[] = [
  {
    id: "1",
    studentId: "2",
    studentAd: "Elvin Həsənov",
    telefon: "+994 51 234 56 78",
    növ: "whatsapp",
    mesaj: "Hörmətli Elvin, ödəniş müddətiniz keçib. Zəhmət olmasa 500 AZN borcunuzu ödəyin.",
    status: "göndərilib",
    göndərilməTarixi: "2024-03-18",
    planlanmışTarix: "2024-03-18",
  },
  {
    id: "2",
    studentId: "5",
    studentAd: "Nigar Quliyeva",
    telefon: "+994 77 567 89 01",
    növ: "sms",
    mesaj: "Hörmətli Nigar, növbəti ödənişiniz 25 mart tarixindədir. 150 AZN.",
    status: "gözləyir",
    planlanmışTarix: "2024-03-23",
  },
  {
    id: "3",
    studentId: "3",
    studentAd: "Leyla İbrahimova",
    telefon: "+994 55 345 67 89",
    növ: "whatsapp",
    mesaj: "Hörmətli Leyla, qalan 75 AZN borcunuzu ödəməyi unutmayın.",
    status: "gözləyir",
    planlanmışTarix: "2024-03-24",
  },
]
