"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Upload, Search, Eye, Download, CheckCircle, XCircle, Clock } from "lucide-react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"

type Receipt = {
  id: string
  studentId: string
  studentAd: string
  məbləğ: number
  tarix: string
  status: "təsdiqləndi" | "gözləyir" | "rədd edildi"
  qəbzUrl: string
  yükləməTarixi: string
}

const mockReceipts: Receipt[] = [
  {
    id: "1",
    studentId: "1",
    studentAd: "Ayşən Məmmədova",
    məbləğ: 150,
    tarix: "2024-03-15",
    status: "təsdiqləndi",
    qəbzUrl: "/generic-bank-receipt.png",
    yükləməTarixi: "2024-03-15 14:30",
  },
  {
    id: "2",
    studentId: "2",
    studentAd: "Elvin Həsənov",
    məbləğ: 250,
    tarix: "2024-03-10",
    status: "gözləyir",
    qəbzUrl: "/payment-receipt.png",
    yükləməTarixi: "2024-03-10 10:15",
  },
  {
    id: "3",
    studentId: "3",
    studentAd: "Leyla İbrahimova",
    məbləğ: 75,
    tarix: "2024-03-08",
    status: "təsdiqləndi",
    qəbzUrl: "/transaction-receipt.jpg",
    yükləməTarixi: "2024-03-08 16:45",
  },
  {
    id: "4",
    studentId: "5",
    studentAd: "Nigar Quliyeva",
    məbləğ: 150,
    tarix: "2024-03-05",
    status: "rədd edildi",
    qəbzUrl: "/bank-slip.jpg",
    yükləməTarixi: "2024-03-05 11:20",
  },
]

export default function ReceiptsPage() {
  const [receipts, setReceipts] = useState<Receipt[]>(mockReceipts)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("hamısı")
  const [selectedReceipt, setSelectedReceipt] = useState<Receipt | null>(null)

  const filteredReceipts = receipts.filter((receipt) => {
    const matchesSearch = receipt.studentAd.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "hamısı" || receipt.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleStatusChange = (receiptId: string, newStatus: "təsdiqləndi" | "rədd edildi") => {
    setReceipts(receipts.map((r) => (r.id === receiptId ? { ...r, status: newStatus } : r)))
    setSelectedReceipt(null)
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="ml-64 flex-1">
        <Header />
        <main className="p-6">
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold tracking-tight">Qəbzlər</h1>
                <p className="text-muted-foreground">Tələbələrin yüklədikləri ödəniş qəbzləri</p>
              </div>
              <Button className="gap-2">
                <Upload className="h-4 w-4" />
                Qəbz Yüklə
              </Button>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Qəbz İdarəetməsi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Tələbə axtar..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hamısı">Hamısı</SelectItem>
                    <SelectItem value="gözləyir">Gözləyir</SelectItem>
                    <SelectItem value="təsdiqləndi">Təsdiqləndi</SelectItem>
                    <SelectItem value="rədd edildi">Rədd Edildi</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tələbə</TableHead>
                      <TableHead>Məbləğ</TableHead>
                      <TableHead>Tarix</TableHead>
                      <TableHead>Yüklənmə</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Əməliyyatlar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredReceipts.map((receipt) => (
                      <TableRow key={receipt.id}>
                        <TableCell className="font-medium">{receipt.studentAd}</TableCell>
                        <TableCell>{receipt.məbləğ} AZN</TableCell>
                        <TableCell>{receipt.tarix}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">{receipt.yükləməTarixi}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              receipt.status === "təsdiqləndi"
                                ? "default"
                                : receipt.status === "gözləyir"
                                  ? "secondary"
                                  : "destructive"
                            }
                            className="gap-1"
                          >
                            {receipt.status === "təsdiqləndi" && <CheckCircle className="h-3 w-3" />}
                            {receipt.status === "gözləyir" && <Clock className="h-3 w-3" />}
                            {receipt.status === "rədd edildi" && <XCircle className="h-3 w-3" />}
                            {receipt.status === "təsdiqləndi" && "Təsdiqləndi"}
                            {receipt.status === "gözləyir" && "Gözləyir"}
                            {receipt.status === "rədd edildi" && "Rədd Edildi"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedReceipt(receipt)}
                            className="gap-1"
                          >
                            <Eye className="h-4 w-4" />
                            Bax
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {filteredReceipts.length === 0 && (
                <div className="py-8 text-center text-muted-foreground">Heç bir qəbz tapılmadı</div>
              )}
            </CardContent>
          </Card>

          {selectedReceipt && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Qəbz Təfərrüatları</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-muted-foreground">Tələbə</Label>
                      <p className="mt-1 font-medium">{selectedReceipt.studentAd}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Məbləğ</Label>
                      <p className="mt-1 text-2xl font-bold">{selectedReceipt.məbləğ} AZN</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Ödəniş Tarixi</Label>
                      <p className="mt-1 font-medium">{selectedReceipt.tarix}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Yüklənmə Tarixi</Label>
                      <p className="mt-1 font-medium">{selectedReceipt.yükləməTarixi}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Status</Label>
                      <div className="mt-1">
                        <Badge
                          variant={
                            selectedReceipt.status === "təsdiqləndi"
                              ? "default"
                              : selectedReceipt.status === "gözləyir"
                                ? "secondary"
                                : "destructive"
                          }
                          className="gap-1"
                        >
                          {selectedReceipt.status === "təsdiqləndi" && <CheckCircle className="h-3 w-3" />}
                          {selectedReceipt.status === "gözləyir" && <Clock className="h-3 w-3" />}
                          {selectedReceipt.status === "rədd edildi" && <XCircle className="h-3 w-3" />}
                          {selectedReceipt.status === "təsdiqləndi" && "Təsdiqləndi"}
                          {selectedReceipt.status === "gözləyir" && "Gözləyir"}
                          {selectedReceipt.status === "rədd edildi" && "Rədd Edildi"}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Label>Qəbz Şəkli</Label>
                    <div className="overflow-hidden rounded-lg border">
                      <img
                        src={selectedReceipt.qəbzUrl || "/placeholder.svg"}
                        alt="Qəbz"
                        className="h-auto w-full object-cover"
                      />
                    </div>
                    <Button variant="outline" className="w-full gap-2 bg-transparent">
                      <Download className="h-4 w-4" />
                      Yüklə
                    </Button>
                  </div>
                </div>

                {selectedReceipt.status === "gözləyir" && (
                  <div className="flex gap-3 border-t pt-4">
                    <Button
                      onClick={() => handleStatusChange(selectedReceipt.id, "təsdiqləndi")}
                      className="flex-1 gap-2"
                    >
                      <CheckCircle className="h-4 w-4" />
                      Təsdiqlə
                    </Button>
                    <Button
                      onClick={() => handleStatusChange(selectedReceipt.id, "rədd edildi")}
                      variant="destructive"
                      className="flex-1 gap-2"
                    >
                      <XCircle className="h-4 w-4" />
                      Rədd Et
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  )
}
