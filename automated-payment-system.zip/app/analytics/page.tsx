"use client"

import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { students, payments, paymentPlans } from "@/lib/mock-data"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from "recharts"

const COLORS = ["oklch(0.42 0.19 252)", "oklch(0.65 0.22 155)", "oklch(0.75 0.15 75)"]

export default function AnalyticsPage() {
  const paymentStatusData = [
    {
      name: "Ödənilib",
      dəyər: students.filter((s) => s.status === "ödənilib").length,
    },
    {
      name: "Gözləyir",
      dəyər: students.filter((s) => s.status === "gözləyir").length,
    },
    {
      name: "Gecikib",
      dəyər: students.filter((s) => s.status === "gecikib").length,
    },
    {
      name: "Qismən",
      dəyər: students.filter((s) => s.status === "qismən").length,
    },
  ]

  const planDistribution = paymentPlans.map((plan) => ({
    name: plan.ad,
    dəyər: students.filter((s) => s.plan.id === plan.id).length,
  }))

  const monthlyRevenue = [
    { ay: "Yan", gəlir: 1200 },
    { ay: "Fev", gəlir: 1800 },
    { ay: "Mar", gəlir: payments.reduce((sum, p) => sum + p.məbləğ, 0) },
  ]

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="ml-64 flex-1">
        <Header />
        <main className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold">Hesabatlar və Analitika</h1>
            <p className="text-muted-foreground">Maliyyə və tələbə statistikası</p>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Ödəniş Statusu</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={paymentStatusData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.90 0.005 252)" />
                    <XAxis dataKey="name" stroke="oklch(0.52 0.015 252)" />
                    <YAxis stroke="oklch(0.52 0.015 252)" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(1 0 0)",
                        border: "1px solid oklch(0.90 0.005 252)",
                        borderRadius: "8px",
                      }}
                    />
                    <Bar dataKey="dəyər" fill="oklch(0.42 0.19 252)" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Plan Bölgüsü</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={planDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="dəyər"
                    >
                      {planDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(1 0 0)",
                        border: "1px solid oklch(0.90 0.005 252)",
                        borderRadius: "8px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Aylıq Gəlir Trendi</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={monthlyRevenue}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.90 0.005 252)" />
                    <XAxis dataKey="ay" stroke="oklch(0.52 0.015 252)" />
                    <YAxis stroke="oklch(0.52 0.015 252)" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "oklch(1 0 0)",
                        border: "1px solid oklch(0.90 0.005 252)",
                        borderRadius: "8px",
                      }}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="gəlir"
                      stroke="oklch(0.65 0.22 155)"
                      strokeWidth={3}
                      dot={{ fill: "oklch(0.65 0.22 155)", r: 5 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <div className="mt-6 grid gap-6 md:grid-cols-4">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Ödəniş Faizi</p>
                  <p className="text-3xl font-bold">
                    {((students.filter((s) => s.status === "ödənilib").length / students.length) * 100).toFixed(0)}%
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Orta Plan Qiyməti</p>
                  <p className="text-3xl font-bold">
                    {(paymentPlans.reduce((sum, p) => sum + p.məbləğ, 0) / paymentPlans.length).toFixed(0)} ₼
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Aktiv Tələbə</p>
                  <p className="text-3xl font-bold">{students.filter((s) => s.status !== "gecikib").length}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Yığılmalı Məbləğ</p>
                  <p className="text-3xl font-bold">{students.reduce((sum, s) => sum + s.totalDebt, 0)} ₼</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
