"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Bell, Mail, MessageSquare, Building2, CreditCard, Shield } from "lucide-react"

export default function SettingsPage() {
  const [autoReminders, setAutoReminders] = useState(true)
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [smsNotifications, setSmsNotifications] = useState(false)
  const [whatsappNotifications, setWhatsappNotifications] = useState(true)

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 pl-64">
        <Header title="Parametrlər" />
        <main className="p-6 space-y-6">
          {/* Təşkilat Məlumatları */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Təşkilat Məlumatları
              </CardTitle>
              <CardDescription>Təhsil mərkəzinizin əsas məlumatları</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="org-name">Təşkilatın Adı</Label>
                  <Input id="org-name" defaultValue="BrightMind Təhsil Mərkəzi" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="org-phone">Telefon</Label>
                  <Input id="org-phone" defaultValue="+994 12 345 67 89" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="org-email">Email</Label>
                <Input id="org-email" type="email" defaultValue="info@brightmind.az" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="org-address">Ünvan</Label>
                <Textarea id="org-address" defaultValue="Bakı şəhəri, Nəsimi rayonu, Azadlıq prospekti 123" />
              </div>
              <Button>Yadda Saxla</Button>
            </CardContent>
          </Card>

          {/* Ödəniş Parametrləri */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Ödəniş Parametrləri
              </CardTitle>
              <CardDescription>Ödəniş tarixləri və gecikmə qaydaları</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="payment-day">Ödəniş Günü (Ayın)</Label>
                  <Select defaultValue="5">
                    <SelectTrigger id="payment-day">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 5, 10, 15, 20, 25].map((day) => (
                        <SelectItem key={day} value={day.toString()}>
                          {day}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="grace-period">Güzəşt Müddəti (Gün)</Label>
                  <Select defaultValue="3">
                    <SelectTrigger id="grace-period">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[0, 1, 2, 3, 5, 7].map((day) => (
                        <SelectItem key={day} value={day.toString()}>
                          {day} gün
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="late-fee">Gecikdirmə Haqqı (%)</Label>
                <Input id="late-fee" type="number" defaultValue="5" />
              </div>
              <Button>Yadda Saxla</Button>
            </CardContent>
          </Card>

          {/* Bildiriş Parametrləri */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Bildiriş Parametrləri
              </CardTitle>
              <CardDescription>Avtomatik xatırlatma və bildiriş ayarları</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Avtomatik Xatırlatmalar</Label>
                  <p className="text-sm text-muted-foreground">Ödəniş tarixindən əvvəl avtomatik xatırlatma göndər</p>
                </div>
                <Switch checked={autoReminders} onCheckedChange={setAutoReminders} />
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="text-sm font-medium">Bildiriş Kanalları</h4>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <Label>Email Bildirişləri</Label>
                      <p className="text-sm text-muted-foreground">Email vasitəsilə bildiriş göndər</p>
                    </div>
                  </div>
                  <Switch checked={emailNotifications} onCheckedChange={setEmailNotifications} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <Label>SMS Bildirişləri</Label>
                      <p className="text-sm text-muted-foreground">SMS vasitəsilə bildiriş göndər</p>
                    </div>
                  </div>
                  <Switch checked={smsNotifications} onCheckedChange={setSmsNotifications} />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <Label>WhatsApp Bildirişləri</Label>
                      <p className="text-sm text-muted-foreground">WhatsApp vasitəsilə bildiriş göndər</p>
                    </div>
                  </div>
                  <Switch checked={whatsappNotifications} onCheckedChange={setWhatsappNotifications} />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <Label htmlFor="reminder-days">Xatırlatma Müddəti</Label>
                <Select defaultValue="3">
                  <SelectTrigger id="reminder-days">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 gün əvvəl</SelectItem>
                    <SelectItem value="3">3 gün əvvəl</SelectItem>
                    <SelectItem value="5">5 gün əvvəl</SelectItem>
                    <SelectItem value="7">7 gün əvvəl</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground">Ödəniş tarixindən neçə gün əvvəl xatırlatma göndərilsin</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reminder-template">Xatırlatma Mesaj Şablonu</Label>
                <Textarea
                  id="reminder-template"
                  rows={4}
                  defaultValue="Hörmətli {ad}, növbəti ödənişiniz {tarix} tarixindədir. Məbləğ: {məbləğ} AZN. Təşəkkürlər!"
                />
                <p className="text-sm text-muted-foreground">
                  Dəyişənlər: {"{ad}"}, {"{tarix}"}, {"{məbləğ}"}
                </p>
              </div>

              <Button>Yadda Saxla</Button>
            </CardContent>
          </Card>

          {/* Təhlükəsizlik */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Təhlükəsizlik
              </CardTitle>
              <CardDescription>İstifadəçi hesabı və təhlükəsizlik ayarları</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Cari Şifrə</Label>
                <Input id="current-password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">Yeni Şifrə</Label>
                <Input id="new-password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Şifrəni Təsdiq Et</Label>
                <Input id="confirm-password" type="password" />
              </div>
              <Button>Şifrəni Dəyiş</Button>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}
