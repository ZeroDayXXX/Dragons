"use client"

import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Plus, Download, FileText, Calendar } from "lucide-react"
import { payments } from "@/lib/mock-data"
import { StatusBadge } from "@/components/status-badge"
import { useState, useMemo } from "react"

export default function PaymentsPage() {
  const [startDate, setStartDate] = useState<string>("")
  const [endDate, setEndDate] = useState<string>("")

  const filteredPayments = useMemo(() => {
    return payments.filter((payment) => {
      const paymentDate = new Date(payment.tarix)

      if (startDate) {
        const start = new Date(startDate)
        start.setHours(0, 0, 0, 0)
        if (paymentDate < start) return false
      }

      if (endDate) {
        const end = new Date(endDate)
        end.setHours(23, 59, 59, 999)
        if (paymentDate > end) return false
      }

      return true
    })
  }, [startDate, endDate])

  const totalAmount = filteredPayments.reduce((sum, p) => sum + p.məbləğ, 0)

  const exportToCSV = () => {
    const headers = ["Tələbə", "Məbləğ", "Tarix", "Status", "Qeyd"]
    const rows = filteredPayments.map((p) => [p.studentAd, p.məbləğ, p.tarix, p.status, p.qeyd || ""])

    const csvContent = [headers.join(","), ...rows.map((row) => row.map((cell) => `"${cell}"`).join(","))].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = `odenisler_${startDate}_${endDate}.csv`
    link.click()
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="ml-64 flex-1">
        <Header />
        <main className="p-6">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Ödənişlər</h1>
              <p className="text-muted-foreground">Bütün ödəniş əməliyyatları</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={exportToCSV}>
                <Download className="mr-2 h-4 w-4" />
                İxrac (CSV)
              </Button>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Yeni Ödəniş
              </Button>
            </div>
          </div>

          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <Calendar className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-semibold">Tarix Aralığı</h3>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="start-date">Başlanğıc tarixi</Label>
                    <Input
                      id="start-date"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end-date">Bitmə tarixi</Label>
                    <Input id="end-date" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                  </div>
                </div>

                <div className="pt-2 border-t border-border">
                  <p className="text-sm text-muted-foreground">
                    Göstərilir: <span className="font-semibold text-foreground">{startDate || "Başlanğıc yoxdur"}</span>{" "}
                    – <span className="font-semibold text-foreground">{endDate || "Son tarix yoxdur"}</span> •
                    <span className="font-semibold text-primary ml-1">{filteredPayments.length} ödəniş</span>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-3 mb-6">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Seçilmiş Dövrün Gəliri</p>
                  <p className="text-3xl font-bold">{totalAmount} ₼</p>
                  <p className="text-xs text-success">{filteredPayments.length} əməliyyat</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Orta Ödəniş</p>
                  <p className="text-3xl font-bold">
                    {filteredPayments.length > 0 ? (totalAmount / filteredPayments.length).toFixed(0) : 0} ₼
                  </p>
                  <p className="text-xs text-muted-foreground">Əməliyyat başına</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Ödənilmiş Sayı</p>
                  <p className="text-3xl font-bold">{filteredPayments.filter((p) => p.status === "ödənilib").length}</p>
                  <p className="text-xs text-muted-foreground">Tam ödənişlər</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Ödəniş Tarixçəsi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border text-left">
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Tələbə</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Məbləğ</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Tarix</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Status</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Qəbz</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Qeyd</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPayments.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-muted-foreground">
                          Seçilmiş tarix aralığında ödəniş tapılmadı
                        </td>
                      </tr>
                    ) : (
                      filteredPayments.map((payment) => (
                        <tr key={payment.id} className="border-b border-border last:border-0">
                          <td className="py-4">
                            <p className="font-medium">{payment.studentAd}</p>
                          </td>
                          <td className="py-4">
                            <p className="font-semibold text-success">+{payment.məbləğ} ₼</p>
                          </td>
                          <td className="py-4">
                            <p className="text-sm text-muted-foreground">{payment.tarix}</p>
                          </td>
                          <td className="py-4">
                            <StatusBadge status={payment.status} />
                          </td>
                          <td className="py-4">
                            {payment.qəbz ? (
                              <Button variant="ghost" size="sm">
                                <FileText className="h-4 w-4" />
                              </Button>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="py-4">
                            <p className="text-sm text-muted-foreground">{payment.qeyd || "-"}</p>
                          </td>
                          <td className="py-4">
                            <Button variant="ghost" size="sm">
                              Detallar
                            </Button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}
