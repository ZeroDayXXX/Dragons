import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { StatCard } from "@/components/stat-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, DollarSign, AlertCircle, TrendingUp, Clock, CheckCircle2 } from "lucide-react"
import { students, payments, reminders } from "@/lib/mock-data"
import { StatusBadge } from "@/components/status-badge"
import Link from "next/link"

export default function DashboardPage() {
  const totalStudents = students.length
  const activeStudents = students.filter((s) => s.status !== "gecikib").length
  const totalRevenue = payments.reduce((sum, p) => sum + p.məbləğ, 0)
  const totalDebt = students.reduce((sum, s) => sum + s.totalDebt, 0)
  const overdueStudents = students.filter((s) => s.status === "gecikib").length
  const pendingReminders = reminders.filter((r) => r.status === "gözləyir").length

  const recentPayments = payments.slice(-5).reverse()
  const upcomingReminders = reminders.filter((r) => r.status === "gözləyir").slice(0, 5)

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="ml-64 flex-1">
        <Header />
        <main className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold">Ana Səhifə</h1>
            <p className="text-muted-foreground">Ödəniş sisteminin ümumi görünüşü</p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <StatCard
              title="Ümumi Tələbə"
              value={totalStudents.toString()}
              change={`${activeStudents} aktiv`}
              changeType="positive"
              icon={Users}
              iconBg="bg-primary"
            />
            <StatCard
              title="Bu ay Gəlir"
              value={`${totalRevenue} ₼`}
              change="+12% keçən aya nəzərən"
              changeType="positive"
              icon={DollarSign}
              iconBg="bg-success"
            />
            <StatCard
              title="Ümumi Borc"
              value={`${totalDebt} ₼`}
              change={`${overdueStudents} tələbə`}
              changeType="negative"
              icon={AlertCircle}
              iconBg="bg-destructive"
            />
            <StatCard
              title="Gözləyən Xatırlatma"
              value={pendingReminders.toString()}
              change="Bu həftə göndəriləcək"
              changeType="neutral"
              icon={Clock}
              iconBg="bg-warning"
            />
          </div>

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Son Ödənişlər</CardTitle>
                <Link href="/payments">
                  <Button variant="ghost" size="sm">
                    Hamısına bax
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentPayments.map((payment) => (
                    <div
                      key={payment.id}
                      className="flex items-center justify-between border-b border-border pb-4 last:border-0 last:pb-0"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-success/10">
                          <CheckCircle2 className="h-5 w-5 text-success" />
                        </div>
                        <div>
                          <p className="font-medium">{payment.studentAd}</p>
                          <p className="text-sm text-muted-foreground">{payment.tarix}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-success">+{payment.məbləğ} ₼</p>
                        <StatusBadge status={payment.status} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Planlanmış Xatırlatmalar</CardTitle>
                <Link href="/reminders">
                  <Button variant="ghost" size="sm">
                    Hamısına bax
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingReminders.map((reminder) => (
                    <div
                      key={reminder.id}
                      className="flex items-center justify-between border-b border-border pb-4 last:border-0 last:pb-0"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                          <Clock className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{reminder.studentAd}</p>
                          <p className="text-sm text-muted-foreground">
                            {reminder.növ === "whatsapp" ? "WhatsApp" : "SMS"}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">{reminder.planlanmışTarix}</p>
                        <span className="inline-flex items-center rounded-full bg-warning/10 px-2.5 py-0.5 text-xs font-medium text-warning-foreground">
                          Gözləyir
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Tez Görünüş</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <Link href="/students">
                  <div className="flex items-center gap-4 rounded-lg border border-border p-4 transition-colors hover:bg-secondary">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold">Tələbələri İdarə Et</p>
                      <p className="text-sm text-muted-foreground">Tələbə əlavə et və redaktə et</p>
                    </div>
                  </div>
                </Link>
                <Link href="/reminders">
                  <div className="flex items-center gap-4 rounded-lg border border-border p-4 transition-colors hover:bg-secondary">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-warning/10">
                      <Clock className="h-6 w-6 text-warning" />
                    </div>
                    <div>
                      <p className="font-semibold">Xatırlatma Göndər</p>
                      <p className="text-sm text-muted-foreground">SMS və WhatsApp mesajları</p>
                    </div>
                  </div>
                </Link>
                <Link href="/analytics">
                  <div className="flex items-center gap-4 rounded-lg border border-border p-4 transition-colors hover:bg-secondary">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-success/10">
                      <TrendingUp className="h-6 w-6 text-success" />
                    </div>
                    <div>
                      <p className="font-semibold">Hesabatlara Bax</p>
                      <p className="text-sm text-muted-foreground">Gəlir və statistika</p>
                    </div>
                  </div>
                </Link>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}
