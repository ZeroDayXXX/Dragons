import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Send, MessageSquare, Smartphone } from "lucide-react"
import { reminders } from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"

export default function RemindersPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="ml-64 flex-1">
        <Header />
        <main className="p-6">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Xatırlatmalar</h1>
              <p className="text-muted-foreground">SMS və WhatsApp mesajları idarə edin</p>
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Yeni Xatırlatma
            </Button>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">Gözləyir</span>
                    <Badge variant="secondary">{reminders.filter((r) => r.status === "gözləyir").length}</Badge>
                  </div>
                  <p className="text-2xl font-bold">{reminders.filter((r) => r.status === "gözləyir").length}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">Göndərilib</span>
                    <Badge variant="secondary" className="bg-success/10 text-success">
                      {reminders.filter((r) => r.status === "göndərilib").length}
                    </Badge>
                  </div>
                  <p className="text-2xl font-bold">{reminders.filter((r) => r.status === "göndərilib").length}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">Uğursuz</span>
                    <Badge variant="secondary" className="bg-destructive/10 text-destructive">
                      {reminders.filter((r) => r.status === "uğursuz").length}
                    </Badge>
                  </div>
                  <p className="text-2xl font-bold">{reminders.filter((r) => r.status === "uğursuz").length}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Xatırlatma Siyahısı</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reminders.map((reminder) => (
                  <div
                    key={reminder.id}
                    className="flex items-start justify-between rounded-lg border border-border p-4"
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className={`flex h-12 w-12 items-center justify-center rounded-full ${
                          reminder.növ === "whatsapp" ? "bg-success/10" : "bg-primary/10"
                        }`}
                      >
                        {reminder.növ === "whatsapp" ? (
                          <MessageSquare
                            className={`h-6 w-6 ${reminder.növ === "whatsapp" ? "text-success" : "text-primary"}`}
                          />
                        ) : (
                          <Smartphone className="h-6 w-6 text-primary" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-semibold">{reminder.studentAd}</p>
                          <Badge
                            variant={
                              reminder.status === "göndərilib"
                                ? "default"
                                : reminder.status === "uğursuz"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {reminder.status === "göndərilib" && "Göndərilib"}
                            {reminder.status === "gözləyir" && "Gözləyir"}
                            {reminder.status === "uğursuz" && "Uğursuz"}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{reminder.telefon}</p>
                        <p className="text-sm border-l-2 border-primary pl-3 py-1 bg-secondary/50 rounded">
                          {reminder.mesaj}
                        </p>
                        <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                          <span>Planlanmış: {reminder.planlanmışTarix}</span>
                          {reminder.göndərilməTarixi && <span>Göndərilib: {reminder.göndərilməTarixi}</span>}
                        </div>
                      </div>
                    </div>
                    {reminder.status === "gözləyir" && (
                      <Button size="sm" className="ml-4">
                        <Send className="mr-2 h-3 w-3" />
                        Göndər
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}
