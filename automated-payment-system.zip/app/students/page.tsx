"use client"

import { useState, useMemo } from "react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, MoreVertical, Phone, Mail, Filter } from "lucide-react"
import { students, groups } from "@/lib/mock-data"
import { StatusBadge } from "@/components/status-badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function StudentsPage() {
  const [selectedGroup, setSelectedGroup] = useState<string>("all")
  const [selectedStudent, setSelectedStudent] = useState<string>("all")
  const [selectedPayStatus, setSelectedPayStatus] = useState<string>("all")

  const availableStudents = useMemo(() => {
    if (selectedGroup === "all") return students
    return students.filter((s) => s.group_id === selectedGroup)
  }, [selectedGroup])

  const filteredStudents = useMemo(() => {
    let result = students

    // Group filter
    if (selectedGroup !== "all") {
      result = result.filter((s) => s.group_id === selectedGroup)
    }

    // Student filter
    if (selectedStudent !== "all") {
      result = result.filter((s) => s.id === selectedStudent)
    }

    // Payment status filter
    if (selectedPayStatus !== "all") {
      result = result.filter((s) => s.status === selectedPayStatus)
    }

    return result
  }, [selectedGroup, selectedStudent, selectedPayStatus])

  const handleGroupChange = (value: string) => {
    setSelectedGroup(value)
    setSelectedStudent("all")
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="ml-64 flex-1">
        <Header />
        <main className="p-6">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Tələbələr</h1>
              <p className="text-muted-foreground">Bütün tələbələri idarə edin</p>
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Yeni Tələbə
            </Button>
          </div>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Filter className="h-5 w-5" />
                Filtrlər
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                {/* Group Filter */}
                <div>
                  <label className="mb-2 block text-sm font-medium">Qrup</label>
                  <Select value={selectedGroup} onValueChange={handleGroupChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Qrup seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Bütün qruplar</SelectItem>
                      {groups.map((group) => (
                        <SelectItem key={group.id} value={group.id}>
                          {group.ad}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Student Filter */}
                <div>
                  <label className="mb-2 block text-sm font-medium">Tələbə</label>
                  <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tələbə seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Hamısı</SelectItem>
                      {availableStudents.map((student) => (
                        <SelectItem key={student.id} value={student.id}>
                          {student.ad} {student.soyad}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Payment Status Filter */}
                <div>
                  <label className="mb-2 block text-sm font-medium">Ödəniş Statusu</label>
                  <Select value={selectedPayStatus} onValueChange={setSelectedPayStatus}>
                    <SelectTrigger>
                      <SelectValue placeholder="Status seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Hamısı</SelectItem>
                      <SelectItem value="ödənilib">Ödənilmiş</SelectItem>
                      <SelectItem value="gecikib">Gecikən</SelectItem>
                      <SelectItem value="qismən">Qismən</SelectItem>
                      <SelectItem value="gözləyir">Gözləyir</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="mt-4 text-sm text-muted-foreground">
                Nəticə: <span className="font-semibold text-foreground">{filteredStudents.length}</span> tələbə
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Tələbə Siyahısı</CardTitle>
                <Input placeholder="Axtar..." className="w-64" />
              </div>
            </CardHeader>
            <CardContent>
              {filteredStudents.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground">Seçilmiş filtrlərə uyğun tələbə tapılmadı</div>
              ) : (
                <div className="space-y-4">
                  {filteredStudents.map((student) => (
                    <div
                      key={student.id}
                      className="flex items-center justify-between rounded-lg border border-border p-4"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 font-semibold text-primary">
                          {student.ad[0]}
                          {student.soyad[0]}
                        </div>
                        <div>
                          <p className="font-semibold">
                            {student.ad} {student.soyad}
                          </p>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {student.telefon}
                            </span>
                            <span className="flex items-center gap-1">
                              <Mail className="h-3 w-3" />
                              {student.email}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <p className="text-sm font-medium">{student.plan.ad}</p>
                          <p className="text-xs text-muted-foreground">
                            {student.plan.məbləğ} ₼ / {student.plan.müddət}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">Növbəti ödəniş</p>
                          <p className="text-xs text-muted-foreground">{student.nextPaymentDate}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">
                            {student.totalDebt > 0 ? `${student.totalDebt} ₼` : "Borc yoxdur"}
                          </p>
                          <StatusBadge status={student.status} />
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>Redaktə et</DropdownMenuItem>
                            <DropdownMenuItem>Ödəniş tarixçəsi</DropdownMenuItem>
                            <DropdownMenuItem>Xatırlatma göndər</DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive">Sil</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}
