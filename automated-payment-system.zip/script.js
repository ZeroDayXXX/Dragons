// Dashboard Page
const students = [] // Declare the students variable
const payments = [] // Declare the payments variable
const reminders = [] // Declare the reminders variable

function getStatusBadge(status) {
  // Implement getStatusBadge function
  return `<span class="badge ${status}">${status}</span>`
}

if (window.location.pathname.endsWith("index.html") || window.location.pathname === "/") {
  document.addEventListener("DOMContentLoaded", () => {
    // Calculate stats
    const totalStudents = students.length
    const activeStudents = students.filter((s) => s.status !== "gecikib").length
    const totalRevenue = payments.reduce((sum, p) => sum + p.məbləğ, 0)
    const totalDebt = students.reduce((sum, s) => sum + s.totalDebt, 0)
    const overdueStudents = students.filter((s) => s.status === "gecikib").length
    const pendingReminders = reminders.filter((r) => r.status === "gözləyir").length

    // Update stats
    document.getElementById("totalStudents").textContent = totalStudents
    document.getElementById("activeStudents").textContent = `${activeStudents} aktiv`
    document.getElementById("totalRevenue").textContent = `${totalRevenue} ₼`
    document.getElementById("totalDebt").textContent = `${totalDebt} ₼`
    document.getElementById("overdueStudents").textContent = `${overdueStudents} tələbə`
    document.getElementById("pendingReminders").textContent = pendingReminders

    // Recent payments
    const recentPayments = payments.slice(-5).reverse()
    const paymentsHtml = recentPayments
      .map(
        (payment) => `
      <div class="payment-item">
        <div class="payment-info">
          <div class="payment-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/>
            </svg>
          </div>
          <div class="payment-details">
            <h4>${payment.studentAd}</h4>
            <p>${payment.tarix}</p>
          </div>
        </div>
        <div class="payment-amount">
          <h4>+${payment.məbləğ} ₼</h4>
          ${getStatusBadge(payment.status)}
        </div>
      </div>
    `,
      )
      .join("")
    document.getElementById("recentPayments").innerHTML = paymentsHtml

    // Upcoming reminders
    const upcomingReminders = reminders.filter((r) => r.status === "gözləyir").slice(0, 5)
    const remindersHtml = upcomingReminders
      .map(
        (reminder) => `
      <div class="reminder-item">
        <div class="reminder-info">
          <div class="reminder-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
            </svg>
          </div>
          <div class="reminder-details">
            <h4>${reminder.studentAd}</h4>
            <p>${reminder.növ === "whatsapp" ? "WhatsApp" : "SMS"}</p>
          </div>
        </div>
        <div class="reminder-time">
          <p>${reminder.planlanmışTarix}</p>
          ${getStatusBadge(reminder.status)}
        </div>
      </div>
    `,
      )
      .join("")
    document.getElementById("upcomingReminders").innerHTML = remindersHtml
  })
}
